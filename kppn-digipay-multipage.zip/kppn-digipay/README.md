# KPPN Digipay Monitoring — Multi-page + Netlify Functions

Struktur baru dari aplikasi Anda: setiap menu sekarang jadi halaman HTML sendiri,
dan **Supabase key sudah tidak ada sama sekali di kode front-end**. Semua akses ke
Supabase melewati Netlify Functions (server-side), sesuai yang Anda pilih (Opsi B).

## Struktur folder

```
kppn-digipay/
├── netlify.toml              <- konfigurasi Netlify (build, functions, redirect)
├── package.json              <- dependency @supabase/supabase-js untuk functions
├── index.html                <- redirect ke login/dashboard
├── login.html
├── dashboard.html
├── satker.html
├── transaksi.html
├── proses.html
├── rekap.html
├── admin.html
├── assets/
│   ├── css/ (style.css, login.css)
│   └── js/
│       ├── config.js         <- hanya path API, TIDAK ada key
│       ├── api.js            <- fetch wrapper ke /.netlify/functions/*
│       ├── auth-guard.js     <- cek session localStorage di tiap halaman
│       ├── sidebar.js        <- render menu sidebar (link antar halaman)
│       ├── calc.js           <- perhitungan sheet-proses & rekap + kop surat PDF
│       └── login.js, dashboard.js, satker.js, transaksi.js, proses.js, rekap.js, admin.js
└── netlify/
    └── functions/
        ├── _supabaseClient.js  <- baca SUPABASE_URL & SUPABASE_KEY dari env (server-side)
        ├── auth.js              <- POST: verifikasi login
        ├── satker.js             <- GET/POST/PUT tbl_satker
        ├── transaksi.js          <- GET/POST/PUT/DELETE tbl_transaksi
        └── admin.js               <- GET/POST/PUT/DELETE admin
```

## Kenapa key sekarang aman

Sebelumnya `SUPABASE_URL` dan key ditulis langsung di `index.html`, jadi siapa
pun yang buka "View Source" bisa melihatnya. Sekarang:

- Browser **tidak pernah** memuat `@supabase/supabase-js` atau key apa pun.
- Semua permintaan data dari halaman (`api.get/post/put/delete`) memanggil
  endpoint di server Anda sendiri: `/.netlify/functions/...`.
- Function itu baru membaca `SUPABASE_URL` / `SUPABASE_KEY` dari **Environment
  Variables Netlify**, lalu memanggil Supabase dari server — bukan dari browser
  pengguna. Kredensial ini tidak pernah dikirim ke client.

## Langkah deploy ke Netlify

### 1. Push folder ini ke GitHub
Buat repo baru (atau replace isi repo `digipay` yang sudah ada) dengan seluruh
isi folder `kppn-digipay/` ini sebagai root repo.

### 2. Import ke Netlify
- New site from Git → pilih repo Anda.
- Build command: `npm install`
- Publish directory: `.` (root)
- (Sudah otomatis diatur lewat `netlify.toml`, jadi form ini biasanya terisi otomatis)

### 3. Set Environment Variables (WAJIB — ini yang menyembunyikan key)
Di Netlify dashboard: **Site settings → Environment variables → Add a variable**

| Key | Value |
|---|---|
| `SUPABASE_URL` | `https://tpmmpzsujmhadmsaynsa.supabase.co` |
| `SUPABASE_KEY` | (anon/public key Supabase Anda) |

> Catatan: karena Netlify Functions berjalan di server, Anda **boleh** juga
> memakai *service_role key* di sini kalau ingin melewati Row Level Security.
> Tapi jika Anda memakainya, jangan pernah taruh service_role key di kode
> front-end — hanya di Environment Variables ini.

Setelah menambahkan variabel, klik **Deploy → Trigger deploy** supaya function
membaca env yang baru.

### 4. Redeploy & test
- Buka `https://nama-site-anda.netlify.app/login.html`
- Login dengan akun admin yang ada di tabel `admin`
- Cek tiap menu (Dashboard, Data Satker, Data Transaksi, Proses, Rekap, Manajemen Admin)

### 5. Cek keamanan
- Buka DevTools → tab **Sources**/**Network** → cari file JS apa pun di situs
  Anda. Tidak akan ada `SUPABASE_KEY` di mana pun.
- Coba akses `https://nama-site-anda.netlify.app/.netlify/functions/satker`
  langsung di browser — ini akan mengembalikan data JSON (karena GET memang
  dibuat publik-terautentikasi via session app), tapi key Supabase asli tetap
  tidak pernah terkirim ke browser.

## Menjalankan/Test lokal (opsional)
Kalau Anda install [Netlify CLI](https://docs.netlify.com/cli/get-started/):

```bash
npm install
npm install -g netlify-cli
netlify env:set SUPABASE_URL "https://tpmmpzsujmhadmsaynsa.supabase.co"
netlify env:set SUPABASE_KEY "isi-key-anda"
netlify dev
```

Lalu buka `http://localhost:8888/login.html`.

## Catatan lanjutan (opsional, tidak wajib)
- Endpoint GET pada `satker`, `transaksi`, dan `admin` saat ini tidak dicek
  session di sisi server — proteksi login yang ada hanya di sisi browser
  (localStorage). Untuk keamanan tambahan di masa depan, Anda bisa menambahkan
  token sederhana yang dikirim dari `login.js` dan divalidasi di setiap
  Function sebelum query ke Supabase.
- Tabel `admin` masih menyimpan password dalam bentuk plain text (sama seperti
  versi sebelumnya). Kalau mau ditingkatkan, hashing password (mis. bcrypt) di
  dalam `netlify/functions/auth.js` dan `admin.js` adalah langkah lanjutan yang
  disarankan.
